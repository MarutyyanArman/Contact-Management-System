﻿namespace ContactManagement.AM.Lib;

public class ContactService
{
    private List<Contact> contacts = [
        new Contact(){FirstName="Hrach", LastName="Poghosyan", Email="hp@test.com", PhoneNumber="077000111", WorkNumber="099111222" },
        new Contact(){FirstName="Arman", LastName="Marutyan", Email="amarutyan99@gmail.com", PhoneNumber="010334872", WorkNumber="" },
        new Contact(){FirstName="Vazgen", LastName="Simonyan", Email="vazg2@mail.ru", PhoneNumber="095144824", WorkNumber="033333333" },
        new Contact(){FirstName="Poghos", LastName="Davtyan", Email="", PhoneNumber="098888444", WorkNumber="" },
        new Contact(){FirstName="Arman", LastName="Mnacakanyan", Email="", PhoneNumber="094772773", WorkNumber="077777777" },
        ];

    public List<Contact> GetContacts()
    {
        return contacts;
    }

    public void AddContact(Contact contact)
    {
        contacts.Add(contact);
    }

    public void DeleteContact(int id)
    {
        var contact = contacts.FirstOrDefault(c => c.Id == id);
        if (contact != null)
            contacts.Remove(contact);
    }

    public void UpdateContact(Contact updatedContact)
    {
        var existingContact = contacts.FirstOrDefault(c => c.Email == updatedContact.Email);
        if (existingContact != null)
        {
            existingContact.FirstName = updatedContact.FirstName;
            existingContact.LastName = updatedContact.LastName;
            existingContact.PhoneNumber = updatedContact.PhoneNumber;
            existingContact.WorkNumber = updatedContact.WorkNumber;
        }
    }
}